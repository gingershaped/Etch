from . import json, net, rand, str

def setup(i):
    json.setup(i)
    net.setup(i)
    rand.setup(i)
    str.setup(i)