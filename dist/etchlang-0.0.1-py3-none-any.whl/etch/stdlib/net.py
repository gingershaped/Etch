def setup(i):
    pass