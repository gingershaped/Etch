# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['etch', 'etch.mixins', 'etch.parser', 'etch.stdlib']

package_data = \
{'': ['*']}

install_requires = \
['sly>=0.4,<0.5']

extras_require = \
{'repl': ['etchrepl==1.0']}

setup_kwargs = {
    'name': 'etchlang',
    'version': '0.0.1',
    'description': 'Etch, an easy-to use, high-level, interpreted lang based on Python.',
    'long_description': None,
    'author': 'Ginger Industries',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
